package com.todoNew.todo2.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.todoNew.todo2.Models.Todo;

@Service
public class TodoService {
	private  List<Todo> taskList =  new ArrayList<Todo>();
	
	public List<Todo> getAllTask() {
		return taskList;
	}
	
	public int addTask(Todo task) {
		task.setId(taskList.size() + 1);
		taskList.add(task);
		return taskList.size();
	}
	
	public void deleteTask(Integer id) {
		for(Todo todo : taskList) {
			if(todo.getId() == id) {
				taskList.remove(todo);
			}
		}
	}

	public Todo getTaskById(Integer id) {
		for(Todo todo : taskList) {
			if(todo.getId() == id) {
				return todo;
			}
		}
		
		return null;
	}

}
