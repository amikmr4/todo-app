package com.todoNew.todo2.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.todoNew.todo2.Models.User;

@Service
public class AuthService {
    private  List<User> users =  new ArrayList<User>();
	
	public List<User> getAllUsers() {
		return users;
	}
	
	public int addUser(User user) {
		user.setId(users.size() + 1);
		users.add(user);
		return users.size();
	}

}
