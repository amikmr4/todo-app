package com.todoNew.todo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Todo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Todo2Application.class, args);
	}

}
