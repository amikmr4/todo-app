package com.todoNew.todo2.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.todoNew.todo2.Models.User;
import com.todoNew.todo2.Services.AuthService;

@RestController
@RequestMapping("/auth")
public class AuthenticationController {
    @Autowired
    private AuthService authService;
	
	@PostMapping(path="/")
	public int signup(@RequestBody User user) {
		int id = authService.addUser(user);
		return id;
	}
	
	@GetMapping(path="/")
	public List<User> getAllUser() {
		List<User> users = authService.getAllUsers();
		return users;
	}
}
