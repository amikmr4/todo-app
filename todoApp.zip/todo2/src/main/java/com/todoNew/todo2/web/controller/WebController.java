package com.todoNew.todo2.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebController {
  
	
	@RequestMapping("/")
	public String getTodo(Model model) {
		System.out.println("hello");
		return "/index";
	}
}

