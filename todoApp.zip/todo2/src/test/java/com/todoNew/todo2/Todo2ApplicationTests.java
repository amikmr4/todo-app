package com.todoNew.todo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Todo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
